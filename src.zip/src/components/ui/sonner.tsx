'use client';

import { Toaster as Sonner, type ToasterProps } from 'sonner';
import { CircleCheckIcon, InfoIcon, TriangleAlertIcon, OctagonXIcon, Loader2Icon } from 'lucide-react';

// No usamos useTheme porque no hay ThemeProvider en la app.
// La app es light-only, así que forzamos theme="light" para que sonner
// nunca intente leer el tema del sistema y muestre negro.
const Toaster = (props: ToasterProps) => {
  return (
    <Sonner
      theme="light"
      richColors
      position="top-right"
      duration={3000}
      icons={{
        success: <CircleCheckIcon className="size-4" />,
        info:    <InfoIcon className="size-4" />,
        warning: <TriangleAlertIcon className="size-4" />,
        error:   <OctagonXIcon className="size-4" />,
        loading: <Loader2Icon className="size-4 animate-spin" />,
      }}
      style={{
        '--normal-bg':      'var(--popover)',
        '--normal-text':    'var(--popover-foreground)',
        '--normal-border':  'var(--border)',
        '--border-radius':  'var(--radius)',
      } as React.CSSProperties}
      {...props}
    />
  );
};

export { Toaster };
