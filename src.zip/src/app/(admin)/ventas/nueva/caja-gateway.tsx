'use client';

import { useState, useTransition } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import {
  Banknote, CreditCard, ArrowRightLeft,
  LockOpen, ShoppingCart, TrendingUp, Clock, Hash,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { FormField } from '@/components/ui/form-field';
import { abrirCaja } from '@/actions/caja';
import { abrirCajaSchema, type AbrirCajaFormValues } from '@/lib/validations';
import { formatCurrency, formatTime, formatTimeShort } from '@/lib/utils';
import type { SesionCajaDetalle } from '@/actions/caja';

function duracion(apertura: string): string {
 const ms = Date.now() - new Date(apertura).getTime();
  const h  = Math.floor(ms / 3_600_000);
  const m  = Math.floor((ms % 3_600_000) / 60_000);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

// ─── Pantalla: sin caja abierta ───────────────────────────────────────────────
function SinCaja({ onAbierta }: { onAbierta: () => void }) {
  const [pending, startTransition] = useTransition();
  const { register, handleSubmit, formState: { errors } } = useForm<AbrirCajaFormValues>({
    resolver: zodResolver(abrirCajaSchema),
    defaultValues: { saldo_inicial: '' as unknown as number },
  });

  function onSubmit(data: AbrirCajaFormValues) {
    startTransition(async () => {
      const r = await abrirCaja(data.saldo_inicial);
      if (r?.error) { toast.error(r.error); return; }
      toast.success('¡Caja abierta! Ya puedes empezar a vender.');
      onAbierta();
    });
  }

  return (
    <div className="max-w-sm mx-auto">
      <div className="flex flex-col items-center gap-3 mb-8 text-center">
        <div className="h-14 w-14 rounded-full bg-muted flex items-center justify-center">
          <LockOpen size={24} className="text-muted-foreground" />
        </div>
        <div>
          <h2 className="text-lg font-semibold">Abrir caja para comenzar</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Ingresa el efectivo con el que inicias el día para empezar a registrar ventas.
          </p>
        </div>
      </div>

      <Card className="px-5 py-5">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
          <FormField
            label="Fondo inicial en efectivo (MXN)"
            type="number"
            min="0"
            step="0.01"
            placeholder="0.00"
            description="Es el dinero que ya tienes en la caja antes de empezar"
            error={errors.saldo_inicial?.message}
            autoFocus
            {...register('saldo_inicial')}
          />
          <Button type="submit" variant="default" className="w-full" disabled={pending}>
            <LockOpen size={14} />
            {pending ? 'Abriendo caja…' : 'Abrir caja y comenzar a vender'}
          </Button>
        </form>
      </Card>
    </div>
  );
}

// ─── Pantalla: caja abierta — estado para el vendedor ────────────────────────
function CajaAbierta({
  sesion,
  onContinuar,
}: {
  sesion: SesionCajaDetalle;
  onContinuar: () => void;
}) {
  const metodos = [
    { label: 'Efectivo',      icon: <Banknote size={14} />,        value: Number(sesion.monto_efectivo) },
    { label: 'Transferencia', icon: <ArrowRightLeft size={14} />,  value: Number(sesion.monto_transferencia) },
    { label: 'Tarjeta',       icon: <CreditCard size={14} />,      value: Number(sesion.monto_tarjeta) },
  ];

  const cajaActual = Number(sesion.saldo_inicial) + Number(sesion.monto_efectivo);
  console.log('sesion with date current:', sesion.fecha_apertura);


  return (
    <div className="max-w-md w-full mx-auto space-y-5">
     

      {/* Tarjeta principal */}
      <Card className="px-5 py-5 ">
        <div>
          <h2 className="text-sm mb-1 font-semibold">Tu caja está abierta</h2>
          <div className='flex items-center gap-2'>
            <div className='w-1.5 h-1.5 rounded-full bg-green-500'></div>
            <p className="text-xs text-muted-foreground mt-0.5">
              Abierta desde las {formatTimeShort(sesion.fecha_apertura)} · {duracion(sesion.fecha_apertura)} activa
            </p>
          </div>
        </div>
         <Separator />
        {/* Ingresos totales */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-muted-foreground">
            <TrendingUp size={14} />
            <span className="text-xs">Ingresos de la sesión</span>
          </div>
          <p className="text-xl font-bold tabular-nums text-green-700">
            {formatCurrency(Number(sesion.total_ventas))}
          </p>
        </div>

        <Separator />

        {/* Desglose por método */}
        <div className="space-y-2">
          {metodos.map(m => (
            <div key={m.label} className="flex items-center justify-between text-sm">
              <span className="flex items-center gap-1.5 text-muted-foreground">
                {m.icon} {m.label}
              </span>
              <span className="tabular-nums font-medium">
                {m.value > 0 ? formatCurrency(m.value) : <span className="text-muted-foreground/40">—</span>}
              </span>
            </div>
          ))}
        </div>

        <Separator />

        {/* Stats rápidos */}
        <div className="grid grid-cols-3 gap-3 text-center">
          <div>
            <p className="text-[10px] text-muted-foreground mb-0.5">Transacciones</p>
            <p className="text-sm font-bold tabular-nums">{sesion.num_transacciones}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground mb-0.5">Efectivo en caja</p>
            <p className="text-sm font-bold tabular-nums">{formatCurrency(cajaActual)}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground mb-0.5">Fondo inicial</p>
            <p className="text-sm font-bold tabular-nums">{formatCurrency(Number(sesion.saldo_inicial))}</p>
          </div>
        </div>
      </Card>

      {/* CTA */}
      <Button variant="outline" className="w-full shadow" size="lg" onClick={onContinuar}>
        Continuar con la venta
      </Button>
    </div>
  );
}

// ─── Componente principal: gateway ───────────────────────────────────────────
export default function CajaGateway({
  sesionInicial,
}: {
  sesionInicial: SesionCajaDetalle | null;
}) {
  const router = useRouter();
  const [sesion, setSesion] = useState(sesionInicial);
  const [listo, setListo]   = useState(false);

  // Si ya aprobó la pantalla de caja, redirigir al wizard
  if (listo) {
    router.push('/ventas/nueva/wizard');
    return null;
  }

  if (!sesion) {
    return (
      <SinCaja
        onAbierta={() => {
          // Recargar para obtener la sesión recién abierta
          window.location.reload();
        }}
      />
    );
  }

  return (
    <CajaAbierta
      sesion={sesion}
      onContinuar={() => setListo(true)}
    />
  );
}
